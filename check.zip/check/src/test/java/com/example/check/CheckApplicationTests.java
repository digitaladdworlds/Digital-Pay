package com.example.check;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheckApplicationTests {

	@Test
	void contextLoads() {
	}

}
